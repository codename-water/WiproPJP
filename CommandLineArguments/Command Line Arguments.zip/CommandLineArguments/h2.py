from sys import argv

print(argv[1])
print('Name of this file is...',argv[0])