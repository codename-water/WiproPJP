from sys import argv

print('Sum =',int(argv[1])+int(argv[2]))