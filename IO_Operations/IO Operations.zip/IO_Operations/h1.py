f1=open('sample.txt','r')
print('Output from file is...',f1.read())
f1.close()