thisTup=(1, 2, 'a', 3, 'b', 'c', 4, 'd', 5, 6, 'e', 'f', 7)

print('Tuple...',thisTup)
print('4th element in Tuple from start is...',thisTup[3])
print('4th element in Tuple from end is...',thisTup[-4])