thisTup=('1', '2.25', 'a', '3', 'b', 'c', '4', 'd', '5', '6', 'e', 'f', '7')

print('Tuple...',thisTup)

a=input('Enter the element whose index you want to find.')

ind=thisTup.index(a)

print('Index of the element in the tuple is...',ind)