thisDic={}

for i in range(1,16):
    thisDic[i]=i*i
    i+=1
    
print("Dictionary...",thisDic)