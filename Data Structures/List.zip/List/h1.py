thislist=[]

i=0
print("Enter the elements...")
while i < 5:
    a=int(input())
    thislist.append(a)
    i+=1

for i in thislist:
    print(i)