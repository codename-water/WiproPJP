a=input('Enter a string...')

a=a.replace('x','')
a=a.replace('X','')
print('String without \'X\' is...',a)
