def rev(string):
    return string[::-1]


string=input('Enter a string...')
print('Reverse of the string is...',rev(string))