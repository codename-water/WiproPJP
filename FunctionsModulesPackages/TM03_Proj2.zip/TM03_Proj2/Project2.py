import module

name=input('Enter a name.')
module.ispalindrome(name)
module.count_the_vowels(name)
module.frequency_of_letters(name)