a=int(input("Enter a number. "))

if a%2==0:
    print("Number is  even.")
else:
    print("Number is odd.")
