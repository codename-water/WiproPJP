a=int(input("Enter a number. "))

if a<0:
    print("Number is Negative.")
elif a==0:
    print("Number is Zero.")
else:
    print("Number is Positive.")
